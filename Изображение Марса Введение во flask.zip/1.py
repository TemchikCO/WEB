from flask import Flask, url_for

app = Flask(__name__)


@app.route("/")
def base_page():
    return "Миссия Колонизация Марса"


@app.route("/index")
def index_page():
    return "И на Марсе будут яблони цвести!"


@app.route("/promotion")
def promotion_page():
    return '<br>'.join(('Человечество вырастает из детства.',
                        'Человечеству мала одна планета.',
                        'Мы сделаем обитаемыми безжизненные пока планеты.',
                        'И начнем с Марса!',
                        'Присоединяйся!'))


@app.route("/image_mars")
def image_page():
    image_url = url_for("static", filename="img/mars.png")
    text = '''<!doctype html>
            <html lang="ru">
             <head>
                <meta charset="utf-8">
                <title>Привет, Марс!</title>
             </head>
             <body>
                <h1 color="red"> Жди нас, Марс!</h1>
                <img src="{}" alt="картинка Марса">
                <p>Вот она какая, красная планета</p>
             </body>
            </html>

'''.format(image_url)
    return text


@app.route("/promotion_image")
def promo_image_page():
    image_url = url_for("static", filename="img/mars.png")
    style_url = url_for("static", filename="css/style.css")
    text = '''<!doctype html>
                <html lang="ru">
                 <head>
                    <meta charset="utf-8">
                    <title>Привет, Марс!</title>
                    <link rel="stylesheet" type="text/css" href="{}" />
                 </head>
                 <body>
                    <h1 color="red"> Жди нас, Марс!</h1>
                    <img src="{}" alt="картинка Марса">
                    <p>Вот она какая, красная планета</p>
                 </body>
                </html>

    '''.format(style_url, image_url)
    return text


if __name__ == "__main__":
    app.run("127.0.0.1", 8080)
