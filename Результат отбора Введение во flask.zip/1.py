from flask import Flask, url_for, request
app = Flask(__name__)


@app.route("/")
def base_page():
    return "Миссия Колонизация Марса"


@app.route("/index")
def index_page():
    return "И на Марсе будут яблони цвести!"


@app.route("/promotion")
def promotion_page():
    return '<br>'.join(('Человечество вырастает из детства.',
                        'Человечеству мала одна планета.',
                        'Мы сделаем обитаемыми безжизненные пока планеты.',
                        'И начнем с Марса!',
                        'Присоединяйся!'))


@app.route("/image_mars")
def image_page():
    image_url = url_for("static", filename="img/mars.png")
    text = '''<!doctype html>
            <html lang="ru">
             <head>
                <meta charset="utf-8">
                <title>Привет, Марс!</title>
             </head>
             <body>
                <h1 color="red"> Жди нас, Марс!</h1>
                <img src="{}" alt="картинка Марса">
                <p>Вот она какая, красная планета</p>
             </body>
            </html>

'''.format(image_url)
    return text


@app.route("/promotion_image")
def promo_image_page():
    image_url = url_for("static", filename="img/mars.png")
    style_url = url_for("static", filename="css/style.css")
    text_info = ('Человечество вырастает из детства.',
                 'Человечеству мала одна планета.',
                 'Мы сделаем обитаемыми безжизненные пока планеты.',
                 'И начнем с Марса!',
                 'Присоединяйся!')
    text = '''<!doctype html>
                <html lang="ru">
                 <head>
                    <meta charset="utf-8">
                    <title>Привет, Марс!</title>
                    <link rel="stylesheet" type="text/css" href="{}" />
                    <link rel="stylesheet" type="text/css"
                        href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
                        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
                        crossorigin="anonymous">
                 </head>
                 <body>
                    <h1 class=red> Жди нас, Марс!</h1>
                    <img src="{}" alt="картинка Марса">
                    <div class="alert-dark" role="alert">
                        <br><h3>{}</h3>
                    </div>
                    <div class="alert-success" role="alert">
                        <br><h3>{}</h3>
                    </div>
                    <div class="alert-secondary" role="alert">
                        <br><h3>{}</h3>
                    </div>
                    <div class="alert-warning" role="alert">
                        <br><h3>{}</h3>
                    </div>
                    <div class="alert-danger" role="alert">
                        <br><h3>{}</h3>
                    </div>
                 </body>
                </html>

    '''.format(style_url, image_url, *text_info)
    return text


@app.route("/astronaut_selection", methods=['POST', 'GET'])
def form_sample():
    if request.method == 'GET':
        return f'''<!doctype html>
                        <html lang="ru">
                          <head>
                            <meta charset="utf-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                            <link rel="stylesheet"
                            href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
                            integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
                            crossorigin="anonymous">
                            <link rel="stylesheet" type="text/css"
                             href="{url_for('static', filename='css/style.css')}" />
                            <title>Пример формы</title>
                          </head>
                          <body>
                            <h1>Форма для регистрации в суперсекретной системе</h1>
                            <div>
                                <form class="login_form" method="post">
                                    <input class="form-control" id="surname" placeholder="Введите фамилию" name="surname">
                                    <input class="form-control" id="name" placeholder="Введите имя" name="name">
                                    <div>
                                    <br>
                                        <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Введите адрес почты" name="email">
                                    </div>
                                    <div class="form-group">
                                        <label for="classSelect">Какое у вас образование?</label>
                                        <select class="form-control" id="classSelect" name="class">
                                          <option>Начальное</option>
                                          <option>Среднее</option>
                                          <option>Высшее</option>
                                          <option>Послевузовское</option>
                                        </select>
                                     </div>
                                    <br>
                                    <label for="acceptRules">Какие у вас есть профессии?</label>
                                    <div class="form-group form-check">                                        
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">инженер-исследователь</label>
                                        <br>
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">пилот</label>
                                        <br>
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">строитель</label>
                                        <br>
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">экзобиолог</label>
                                        <br>
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">врач</label>
                                        <br>
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">инженер по терраформированию</label>
                                        <br>
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">климатолог</label>
                                        <br>
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">специалист по радиационной защите</label>
                                        <br>
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">штурман</label>
                                        <br>
                                    </div>
                                    <div class="form-group">
                                        <label for="form-check">Укажите пол</label>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="male" value="male" checked>
                                          <label class="form-check-label" for="male">
                                            Мужской
                                          </label>
                                        </div>
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="sex" id="female" value="female">
                                          <label class="form-check-label" for="female">
                                            Женский
                                          </label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="about">Почему Вы хотит принять участие в миссии?</label>
                                        <textarea class="form-control" id="about" rows="3" name="about"></textarea>
                                        <br>
                                    </div>
                                    <div class="form-group">
                                        <label for="photo">Приложите фотографию</label>
                                        <input type="file" class="form-control-file" id="photo" name="file">
                                        <br>
                                    </div>
                                    <div class="form-group form-check">
                                        <br>                                 
                                        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                                        <label class="form-check-label" for="acceptRules">Готовы остаться на Mарсе?</label>
                                        <br>
                                    </div>
                                    <br>
                                    <button type="submit" class="btn btn-primary">Записаться</button>
                                </form>
                            </div>
                          </body>
                        </html>'''
    elif request.method == 'POST':
        print(request.form['surname'])
        print(request.form['name'])
        print(request.form['email'])
        print(request.form['class'])
        print(request.form['file'])
        print(request.form['about'])
        print(request.form['accept'])
        print(request.form['sex'])
        return "Форма отправлена"


@app.route("/choice/<planet_name>")
def planet_info(planet_name):
    style_url = url_for("static", filename="css/style.css")
    text_info = (f'Планета {planet_name} сверхвеличествена.',
                 f'На {planet_name} есть много воды, жизни, богатств',
                 f'Гравитация на планете {planet_name} схожа с гравитацией на Земле',
                 'Да и в принципе, она просто прекрасна')
    text = '''<!doctype html>
                <html lang="ru">
                 <head>
                    <meta charset="utf-8">
                    <title>Привет, Марс!</title>
                    <link rel="stylesheet" type="text/css" href="{}" />
                    <link rel="stylesheet" type="text/css"
                        href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
                        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
                        crossorigin="anonymous">
                 </head>
                 <body>
                    <h1 class=red>Сейчас рассмотрим планету {}!</h1>
                    <div class="alert-dark" role="alert">
                        <br><h3>{}</h3>
                    </div>
                    <div class="alert-success" role="alert">
                        <br><h3>{}</h3>
                    </div>
                    <div class="alert-warning" role="alert">
                        <br><h3>{}</h3>
                    </div>
                    <div class="alert-danger" role="alert">
                        <br><h3>{}</h3>
                    </div>
                 </body>
                </html>

    '''.format(style_url, planet_name, *text_info)
    return text


@app.route("/results/<nickname>/<int:level>/<float:rating>")
def result(nickname, level, rating):
    style_url = url_for("static", filename="css/style.css")
    text_info = (f'Претендента на участиев миссии {nickname}',
                 f'Поздравляем! Ваш рейтинг после {level} этапа отбора',
                 f'составляет {rating}!',
                 'Желаем удачи!')
    text = '''<!doctype html>
                <html lang="ru">
                 <head>
                    <meta charset="utf-8">
                    <title>Результаты</title>
                    <link rel="stylesheet" type="text/css" href="{}" />
                    <link rel="stylesheet" type="text/css"
                        href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
                        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
                        crossorigin="anonymous">
                 </head>
                 <body>
                 <h1>Результаты отбора</h1>
                    <div class="alert-dark" role="alert">
                        <br><h3>{}</h3>
                    </div>
                    <div class="alert-success" role="alert">
                        <br><h3>{}</h3>
                    </div>
                    <div class="alert-warning" role="alert">
                        <br><h3>{}</h3>
                    </div>
                    <div class="alert-danger" role="alert">
                        <br><h3>{}</h3>
                    </div>
                 </body>
                </html>

    '''.format(style_url, *text_info)
    return text


if __name__ == "__main__":
    app.run("127.0.0.1", 8080)
